# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '4987e29a9c04aa1620660ebdeb937371d795ca343fcf029f57c0698e6a334aed6aa5ee657e2b2e7d427969d1bed77f51bb1566508a63eda7bd616ef8ade7cb6f'